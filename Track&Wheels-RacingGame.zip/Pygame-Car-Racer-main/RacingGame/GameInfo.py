import time
import pygame

class GameInfo:
    LEVELS = 3

    def __init__(self, level=1):
        self.level = level
        self.started = False
        self.level_start_time = 0
        self.wins = 0
        self.finished = False
        self.game_start_time = time.time()
        self.level_times = []
        self.speeds = []
        self.current_level_start = time.time()

    def add_win(self):
        self.wins += 1
        level_time = time.time() - self.current_level_start
        self.level_times.append(level_time)

    def next_level(self):
        self.level += 1
        self.started = False
        self.current_level_start = time.time()

    def reset(self):
        self.level = 1
        self.started = False
        self.level_start_time = 0
        self.game_start_time = time.time()
        self.level_times = []
        self.speeds = []
        self.current_level_start = time.time()

    def game_finished(self):
        return self.level > self.LEVELS

    def start_level(self):
        self.started = True
        self.level_start_time = time.time()
        self.current_level_start = time.time()

    def get_level_time(self):
        if not self.started:
            return 0
        return round(time.time() - self.level_start_time)
    
    def get_total_time(self):
        return time.time() - self.game_start_time
    
    def add_speed(self, speed):
        self.speeds.append(speed)
    
    def get_average_speed(self):
        if not self.speeds:
            return 0
        return sum(self.speeds) / len(self.speeds)
    
    def get_stats(self):
        return {
            "total_time": self.get_total_time(),
            "average_speed": self.get_average_speed(),
            "wins": self.wins,
            "total_levels": self.LEVELS,
            "level_times": self.level_times
        }
