import json
import datetime
from typing import List, Dict

class Leaderboard:
    def __init__(self, filename="leaderboard.json"):
        self.filename = filename
        self.entries = self.load_leaderboard()
    
    def load_leaderboard(self) -> List[Dict]:
        """Load leaderboard data from file"""
        try:
            with open(self.filename, 'r') as f:
                return json.load(f)
        except (FileNotFoundError, json.JSONDecodeError):
            return []
    
    def save_leaderboard(self):
        """Save leaderboard data to file"""
        with open(self.filename, 'w') as f:
            json.dump(self.entries, f, indent=2)
    
    def add_entry(self, player_name: str, total_time: float, average_speed: float, 
                  wins: int, total_levels: int, date: str = None):
        """Add a new entry to the leaderboard"""
        if date is None:
            date = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        
        entry = {
            "player_name": player_name,
            "total_time": round(total_time, 2),
            "average_speed": round(average_speed, 2),
            "wins": wins,
            "total_levels": total_levels,
            "date": date,
            "score": self.calculate_score(total_time, wins, total_levels)
        }
        
        self.entries.append(entry)
        # Sort by score (higher is better)
        self.entries.sort(key=lambda x: x["score"], reverse=True)
        # Keep only top 10 entries
        self.entries = self.entries[:10]
        self.save_leaderboard()
    
    def calculate_score(self, total_time: float, wins: int, total_levels: int) -> float:
        """Calculate score based on time, wins, and levels completed"""
        # Lower time is better, more wins is better
        time_score = max(0, 1000 - total_time)  # 1000 - time
        win_score = wins * 100  # 100 points per win
        completion_score = (wins / total_levels) * 500  # Completion percentage
        return time_score + win_score + completion_score
    
    def get_top_entries(self, limit: int = 10) -> List[Dict]:
        """Get top entries from leaderboard"""
        return self.entries[:limit]
    
    def clear_leaderboard(self):
        """Clear all leaderboard entries"""
        self.entries = []
        self.save_leaderboard()


