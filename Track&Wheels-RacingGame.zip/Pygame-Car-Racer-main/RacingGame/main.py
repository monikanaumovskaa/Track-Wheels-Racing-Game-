import pygame
import math
from utils import scale_image, blit_text_center
from GameInfo import GameInfo
from AbstractCar import AbstractCar
from Leaderboard import Leaderboard
import random



pygame.font.init()
pygame.mixer.init()

crash_sound = pygame.mixer.Sound("sounds/crash.mp3")
racing_sound = pygame.mixer.Sound("sounds/racing.mp3")
finish_sound = pygame.mixer.Sound("sounds/finish.mp3")
victory_sound = pygame.mixer.Sound("sounds/victory.mp3")

MENU_BG = pygame.transform.scale(pygame.image.load("imgs/menu_bg.png"), (800, 800))
MENU_BG_NEW = pygame.transform.scale(pygame.image.load("imgs/show_mode_menu.png"), (800, 800))

GRASS = scale_image(pygame.image.load("imgs/grass.jpg"), 2)
RED_CAR = scale_image(pygame.image.load("imgs/red-car.png"), 0.45)
GREEN_CAR = scale_image(pygame.image.load("imgs/green-car.png"), 0.45)
GREY_CAR = scale_image(pygame.image.load("imgs/grey-car.png"), 0.45)
OBSTACLE_IMG = scale_image(pygame.image.load("imgs/obstacle.png"), 0.6)

LEVELS = [
    {
        "TRACK": "imgs/track2.png",
        "TRACK_BORDER": "imgs/track-border2.png",
        "FINISH": "imgs/finish.png",
        "FINISH_POSITION": (380, 240),
        "PATH": [(350, 270), (157, 268), (66, 344), (97, 484), (163, 495),
                 (316, 494), (388, 441), (454, 430), (547, 480), (634, 493),
                 (712, 441), (730, 388), (690, 291), (648, 276), (381, 267)],
        "START_POS": {
            "player": (350, 280, 90),
            "computer": (350, 260, 90)
        }
    },
    {
        "TRACK": "imgs/track1.png",
        "TRACK_BORDER": "imgs/track-border1.png",
        "FINISH": "imgs/finish.png",
        "FINISH_POSITION": (130, 250),
        "PATH": [(175, 119), (110, 70), (56, 133), (70, 481), (318, 731), (404, 680),
                 (418, 521), (507, 475), (600, 551), (613, 715), (736, 713), (734, 399),
                 (611, 357), (409, 343), (433, 257), (697, 258), (738, 123), (581, 71),
                 (303, 78), (275, 377), (176, 388), (178, 260)],
        "START_POS": {
            "player": (180, 200, 0),
            "computer": (150, 200, 0)
        }
    },
    {
        "TRACK": "imgs/track4.png",
        "TRACK_BORDER": "imgs/track-border4.png",
        "FINISH": "imgs/finish.png",
        "FINISH_POSITION": (76, 170),
        "PATH": [(130, 257), (211, 310), (320, 320), (319, 451),
                 (133, 455), (100, 540), (194, 681), (357, 682), (442, 530),
                 (520, 528), (617, 615), (697, 557), (674, 431), (535, 380),
                 (536, 298), (660, 210), (642, 129), (540, 94), (406, 171),
                 (280, 154), (149, 130), (111, 209)],
        "START_POS": {
            "player": (100, 204, 180),
            "computer": (136, 204, 180)
        }
    }
]



def create_random_obstacles(level_data, level_num, num_obstacles=1):
    obstacles = []

    path = level_data["PATH"]


    if len(path) < num_obstacles + 4:
        num_obstacles = max(1, len(path) - 4)

    available_points = path[3:-3]
    selected_points = random.sample(available_points, min(num_obstacles, len(available_points)))

    for point in selected_points:
        x, y = point
        offset_x = random.randint(-40, 40)
        offset_y = random.randint(-40, 40)

        x += offset_x
        y += offset_y

        x = max(60, min(x, 740))
        y = max(60, min(y, 740))

        obstacle_rect = pygame.Rect(x, y, OBSTACLE_IMG.get_width(), OBSTACLE_IMG.get_height())

        too_close = False
        for path_point in path:
            distance = math.sqrt((x - path_point[0]) ** 2 + (y - path_point[1]) ** 2)
            if distance < 50:
                too_close = True
                break

        if not too_close:
            obstacles.append({
                "x": x,
                "y": y,
                "width": OBSTACLE_IMG.get_width(),
                "height": OBSTACLE_IMG.get_height(),
                "rect": obstacle_rect
            })

    return obstacles



WIDTH, HEIGHT = 800, 800
WIN = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Track & Wheels: Formula Racing")
MAIN_FONT = pygame.font.SysFont("comicsans", 50)
FPS = 30


def show_menu():
    start_button = pygame.Rect(250, 600, 300, 80)
    while True:
        WIN.blit(MENU_BG, (0, 0))
        pygame.display.update()
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                exit()
            if event.type == pygame.MOUSEBUTTONDOWN:
                mouse_pos = pygame.mouse.get_pos()
                if start_button.collidepoint(mouse_pos):
                    return


def show_mode_menu():
    single_button = pygame.Rect(250, 600, 300, 70)
    multi_button = pygame.Rect(250, 690, 300, 70)
    ai_button = pygame.Rect(250, 780, 300, 70)

    while True:
        WIN.blit(MENU_BG_NEW, (0, 0))
        pygame.display.update()

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                exit()
            if event.type == pygame.MOUSEBUTTONDOWN:
                mouse_pos = pygame.mouse.get_pos()
                if single_button.collidepoint(mouse_pos):
                    return "single"
                elif multi_button.collidepoint(mouse_pos):
                    return "multi"
                elif ai_button.collidepoint(mouse_pos):
                    return "ai"


class PlayerCar(AbstractCar):
    def __init__(self, img, max_vel, rotation_vel):
        self.IMG = img
        super().__init__(max_vel, rotation_vel)

    def reduce_speed(self):
        self.vel = max(self.vel - self.acceleration / 2, 0)
        self.move()

    def bounce(self):
        self.vel = -self.vel
        self.move()


class ComputerCar(AbstractCar):
    def __init__(self, max_vel, rotation_vel, path=[], car_img=GREY_CAR):
        self.IMG = car_img
        super().__init__(max_vel, rotation_vel)
        self.path = path
        self.current_point = 0
        self.vel = max_vel

    def draw(self, win):
        super().draw(win)

    def calculate_angle(self):
        target_x, target_y = self.path[self.current_point]
        x_diff = target_x - self.x
        y_diff = target_y - self.y
        if y_diff == 0:
            desired_radian_angle = math.pi / 2
        else:
            desired_radian_angle = math.atan(x_diff / y_diff)
        if target_y > self.y:
            desired_radian_angle += math.pi
        diff = self.angle - math.degrees(desired_radian_angle)
        if diff >= 180:
            diff -= 360
        if diff > 0:
            self.angle -= min(self.rotation_vel, abs(diff))
        else:
            self.angle += min(self.rotation_vel, abs(diff))

    def update_path_point(self):
        target = self.path[self.current_point]
        rect = pygame.Rect(self.x, self.y, self.img.get_width(), self.img.get_height())
        if rect.collidepoint(*target):
            self.current_point += 1

    def move(self, obstacles=None):
        if self.current_point >= len(self.path):
            return

        if obstacles:
            if self.collide_with_obstacle(obstacles):
                self.current_point += 1
                if self.current_point >= len(self.path):
                    return
                self.calculate_angle()
                return

            if self.will_hit_obstacle(obstacles):
                self.current_point += 1
                if self.current_point >= len(self.path):
                    return
                self.calculate_angle()
                return

        self.calculate_angle()
        self.update_path_point()
        self.vel = self.max_vel
        super().move()

        if obstacles and self.collide_with_obstacle(obstacles):
            self.current_point += 1
            if self.current_point >= len(self.path):
                return

    def will_hit_obstacle(self, obstacles):
        if not obstacles:
            return False

        radians = math.radians(self.angle)
        next_x = self.x - math.sin(radians) * (self.vel + 10)
        next_y = self.y - math.cos(radians) * (self.vel + 10)

        next_rect = pygame.Rect(next_x, next_y, self.img.get_width(), self.img.get_height())
        for obstacle in obstacles:
            if next_rect.colliderect(obstacle["rect"]):
                return True
        return False

    def bounce(self):
        self.vel = -self.vel
        self.move()

    def next_level(self, level, start_pos):
        self.x, self.y, self.angle = start_pos
        self.vel = self.max_vel + (level - 1) * 0.2
        self.current_point = 0


def draw(win, images, player_car, second_car, game_info, obstacles=None):
    for img, pos in images:
        win.blit(img, pos)

    if obstacles:
        for obstacle in obstacles:
            pygame.draw.rect(win, (255, 255, 255), obstacle["rect"], 3)
            win.blit(OBSTACLE_IMG, (obstacle["x"], obstacle["y"]))

    level_text = MAIN_FONT.render(f"Level {game_info.level}", 1, (255, 255, 255))
    win.blit(level_text, (10, HEIGHT - level_text.get_height() - 70))
    time_text = MAIN_FONT.render(f"Time: {game_info.get_level_time()}s", 1, (255, 255, 255))
    win.blit(time_text, (10, HEIGHT - time_text.get_height() - 40))
    vel_text = MAIN_FONT.render(f"Speed: {round(player_car.vel, 1)}", 1, (255, 255, 255))
    win.blit(vel_text, (10, HEIGHT - vel_text.get_height() - 10))

    game_info.add_speed(player_car.vel)

    player_car.draw(win)
    if second_car:
        second_car.draw(win)


    elapsed = game_info.get_level_time()
    alpha = min(200, elapsed * 5)

    night_overlay = pygame.Surface((WIDTH, HEIGHT))
    night_overlay.set_alpha(alpha)
    night_overlay.fill((0, 0, 0))
    win.blit(night_overlay, (0, 0))

    pygame.display.update()


def show_leaderboard(win, leaderboard, game_stats, player_name="Player"):

    leaderboard.add_entry(
        player_name=player_name,
        total_time=game_stats["total_time"],
        average_speed=game_stats["average_speed"],
        wins=game_stats["wins"],
        total_levels=game_stats["total_levels"]
    )

    top_entries = leaderboard.get_top_entries(10)

    win.fill((255, 255, 255))

    title_font = pygame.font.SysFont("comicsans", 60, bold=True)
    title_text = title_font.render("LeaderBoard", True, (0, 0, 0))
    win.blit(title_text, (WIDTH//2 - title_text.get_width()//2, 50))

    header_font = pygame.font.SysFont("comicsans", 30, bold=True)
    headers = ["Place", "Player", "Avg Speed", "Time (s)"]
    x_positions = [100, 200, 400, 550]
    for i, header in enumerate(headers):
        header_text = header_font.render(header, True, (0, 0, 0))
        win.blit(header_text, (x_positions[i], 150))

    row_font = pygame.font.SysFont("comicsans", 25)
    for i, entry in enumerate(top_entries):
        y_pos = 200 + i * 40

        place = f"{i+1}{'st' if i==0 else 'nd' if i==1 else 'rd' if i==2 else 'th'}"
        texts = [
            place,
            entry["player_name"],
            f"{entry['average_speed']:.1f}",
            f"{entry['total_time']:.1f}"
        ]

        for j, text in enumerate(texts):
            cell = row_font.render(text, True, (0, 0, 0))
            win.blit(cell, (x_positions[j], y_pos))

    instruction_font = pygame.font.SysFont("comicsans", 20)
    instruction_text = instruction_font.render("Press SPACE to play again or ESC to exit", True, (0, 0, 0))
    win.blit(instruction_text, (WIDTH//2 - instruction_text.get_width()//2, HEIGHT - 40))

    pygame.display.update()

    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                return "quit"
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_SPACE:
                    return "restart"
                elif event.key == pygame.K_ESCAPE:
                    return "quit"


def load_level(level_num):
    level_data = LEVELS[level_num - 1]
    track = pygame.transform.scale(pygame.image.load(level_data["TRACK"]), (WIDTH, HEIGHT))
    track_border = pygame.transform.scale(pygame.image.load(level_data["TRACK_BORDER"]), (WIDTH, HEIGHT))
    finish = pygame.transform.scale(pygame.image.load(level_data["FINISH"]), (80, 20))
    finish_position = level_data["FINISH_POSITION"]
    path = level_data["PATH"]
    if level_num == 1:
        finish = pygame.transform.rotate(finish, 90)
    track_border_mask = pygame.mask.from_surface(track_border)
    finish_mask = pygame.mask.from_surface(finish)
    start_pos = level_data.get("START_POS", {"player": (100, 100, 0), "computer": (150, 150, 0)})


    if level_num == 1:
        num_obs = 0
    elif level_num in (2, 3):
        num_obs = 2
    else:
        num_obs = 1

    obstacles = create_random_obstacles(level_data, level_num, num_obstacles=num_obs)

    return track, track_border, finish, finish_position, path, track_border_mask, finish_mask, start_pos, obstacles


def move_players(player1, player2=None):
    keys = pygame.key.get_pressed()
    moved = False
    if keys[pygame.K_a]: player1.rotate(left=True)
    if keys[pygame.K_d]: player1.rotate(right=True)
    if keys[pygame.K_w]:
        moved = True;
        player1.move_forward()
    if keys[pygame.K_s]:
        moved = True;
        player1.move_backward()
    if not moved: player1.reduce_speed()

    if player2:
        moved2 = False
        if keys[pygame.K_LEFT]: player2.rotate(left=True)
        if keys[pygame.K_RIGHT]: player2.rotate(right=True)
        if keys[pygame.K_UP]:
            moved2 = True;
            player2.move_forward()
        if keys[pygame.K_DOWN]:
            moved2 = True;
            player2.move_backward()
        if not moved2: player2.reduce_speed()


def handle_collision_all(cars, track_border_mask, finish_mask, finish_position, start_pos, game_info, mode,
                         obstacles=None):
    for car in cars:
        if car and car.collide(track_border_mask):
            crash_sound.play()
            car.bounce()

        if car and obstacles and car.collide_with_obstacle(obstacles):
            crash_sound.play()
            car.vel = 0
            continue

        finish = car and car.collide(finish_mask, *finish_position)
        if finish:
            if car.vel < 0:
                car.set_start_pos(start_pos["player"])
                car.vel = 0
                continue
            victory_sound.play()
            game_info.add_win()
            game_info.next_level()
            return True
    return False


def main_game():
    show_menu()
    mode = show_mode_menu()

    run = True
    clock = pygame.time.Clock()
    game_info = GameInfo()
    leaderboard = Leaderboard()

    track, track_border, finish, finish_position, path, TRACK_BORDER_MASK, FINISH_MASK, START_POS, obstacles = load_level(
        game_info.level)
    images = [(GRASS, (0, 0)), (track, (0, 0)), (finish, finish_position), (track_border, (0, 0))]

    if mode == "single":
        player_car = PlayerCar(RED_CAR, 4, 4)
        second_car = None
        player_car.set_start_pos(START_POS["player"])
    elif mode == "multi":
        player_car = PlayerCar(RED_CAR, 4, 4)
        second_car = ComputerCar(2, 4, path, GREEN_CAR)
        player_car.set_start_pos(START_POS["player"])
        second_car.set_start_pos(START_POS["computer"])
    elif mode == "ai":
        player_car = PlayerCar(RED_CAR, 4, 4)
        second_car = ComputerCar(2, 4, path, GREY_CAR)
        player_car.set_start_pos(START_POS["player"])
        second_car.set_start_pos(START_POS["computer"])

    while run:
        clock.tick(FPS)
        draw(WIN, images, player_car, second_car, game_info, obstacles)

        if game_info.level > len(LEVELS):
            game_info.finished = True
            game_stats = game_info.get_stats()
            action = show_leaderboard(WIN, leaderboard, game_stats)

            if action == "restart":
                main_game()
            else:
                pygame.quit()
            return

        while not game_info.started:
            blit_text_center(WIN, MAIN_FONT, f"Press any key to start level {game_info.level}!")
            pygame.display.update()
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit(); exit()
                if event.type == pygame.KEYDOWN:
                    game_info.start_level()

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                run = False
                break

        if mode == "ai":
            move_players(player_car)
            second_car.move(obstacles)
        elif mode == "multi":
            move_players(player_car)
            second_car.move(obstacles)
        else:
            move_players(player_car)

        if mode == "single":
            finished = handle_collision_all([player_car], TRACK_BORDER_MASK, FINISH_MASK,
                                            finish_position, START_POS, game_info, mode, obstacles)
        else:
            finished = handle_collision_all([player_car, second_car], TRACK_BORDER_MASK, FINISH_MASK,
                                            finish_position, START_POS, game_info, mode, obstacles)

        if finished:
            if game_info.level > len(LEVELS):
                game_info.finished = True
                game_stats = game_info.get_stats()
                action = show_leaderboard(WIN, leaderboard, game_stats)

                if action == "restart":
                    main_game()
                else:
                    pygame.quit()
                return

            track, track_border, finish, finish_position, path, TRACK_BORDER_MASK, FINISH_MASK, START_POS, obstacles = load_level(
                game_info.level)
            images = [(GRASS, (0, 0)), (track, (0, 0)), (finish, finish_position), (track_border, (0, 0))]

            if mode == "ai":
                second_car = ComputerCar(2, 4, path, GREY_CAR)
                second_car.set_start_pos(START_POS["computer"])
            elif mode == "multi":
                second_car = ComputerCar(2, 4, path, GREEN_CAR)
                second_car.set_start_pos(START_POS["computer"])
            elif mode == "single":
                second_car = None
            player_car.set_start_pos(START_POS["player"])


if __name__ == "__main__":
    main_game()